export const environment = {
  production: true,
  api_endpoint: "/api",
};
